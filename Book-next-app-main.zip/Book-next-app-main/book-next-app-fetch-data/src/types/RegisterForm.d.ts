//src/types/RegisterForm.d.ts
export interface RegisterForm {
  username: string;
  email: string;
  password: string;
}
