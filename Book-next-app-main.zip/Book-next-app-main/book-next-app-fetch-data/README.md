# book-app

# book-app

### API

http://localhost:3001/

### API Document

http://localhost:3000/api-docs

### Mongodb express -> ดูข้อมูลในฐานข้อมูล

http://localhost:8081/
-> username -> admin
-> password -> password123


{
  "username": "teacher",
  "email": "teacher@kku.ac.th",
  "password": "password123"
}
หน้าหลักโชว์หนังสือทั้งหมด
<img width="1919" height="940" alt="image" src="https://github.com/user-attachments/assets/bcce25f7-e0e6-484b-bc64-c50636911b24" />


Create สามารถสร้างหนังสือใหม่ได้
<img width="1919" height="937" alt="image" src="https://github.com/user-attachments/assets/abd13632-8768-4918-a6cd-64ab15e943a1" />



Read สามารถเปิดดูข้อมูลหนังสือทั้งหมด และหนังสือรายเล่มได้
<img width="1913" height="929" alt="image" src="https://github.com/user-attachments/assets/4c698e02-3874-471b-97e5-5f3f4cd31268" />


Update สามารถปรับปรุงข้อมูลหนังสือรายเล่มได้
<img width="1919" height="940" alt="image" src="https://github.com/user-attachments/assets/3134493f-655d-4d12-809b-38bad522574f" />


Delete สามารถลบข้อมูลหนังสือรายเล่มได้
before:
<img width="1919" height="938" alt="image" src="https://github.com/user-attachments/assets/0fa24b5b-1c96-449d-b3d4-1bdfe2c3f32b" />

after:
<img width="1918" height="940" alt="image" src="https://github.com/user-attachments/assets/721d8ba9-8255-42f0-8621-194ca3daaaad" />

login/signin
<img width="1919" height="947" alt="image" src="https://github.com/user-attachments/assets/4619923f-f9a3-4b5f-9610-ff3be2a0f2a1" />

Register
<img width="1919" height="936" alt="image" src="https://github.com/user-attachments/assets/0add1f22-5d7c-4b1a-b9f9-de956da09345" />


หลังจากloginมาแล้วจะพาไปยังหน้าแรกซึ่งทำการแสดงข้อมูลหนังสือทั้งหมด
<img width="1919" height="933" alt="image" src="https://github.com/user-attachments/assets/e03745f7-76f1-4cc8-9f6c-259bc2c811dc" />

ประกอบไปด้วย ส่วนของเพิ่มหนังสือ ชื่อหนังสือ แก้ไขหนังสือ และลบหนังสือ
ซึ่งจะสามารถกดเข้าไปดูรายละเอียดหนังสือผ่านทางชื่อของหนังสือแต่ละเล่มได้
รายละเอียดหนังสือ
<img width="1919" height="943" alt="image" src="https://github.com/user-attachments/assets/0f690958-c2aa-4646-b455-480b95efd847" />

